#!/bin/bash
cd todoapp-flask
python app.py
