TODO 3_0
=========
   记住要做的事情，然后一件件做好
===

+ 这是一个可以给用户 **  记录自己的计划表 **  的简易网站。
+ flask + SQLAlchemy ，可以作为简答学习案例 ，前端用的是pure 
+ todo.py 设计数据库模型 User , Todo，存储在 todos.db 里
+ app.py  设计几个基本路由和视图函数 

---
基本功能：
+ 1 sign  注册
+ 2 login 登陆
+ 3 index 主页， 用户添加和查看自己的任务列表，等任务完成时可以标记任务已经完成。
+ 4 check 检查， 用户查看自己已经完成的任务列表

---

主要的网页截图如下
+ 1 index 主页，用户登录后 ,加和查看自己的任务列表，等任务完成时可以标记任务已经完成。

![image](https://github.com/dodoru/flask_todo/blob/master/static/images/home.jpg)

+ 2 check ，用户查看自己已经完成的任务列表

![image](https://github.com/dodoru/flask_todo/blob/master/static/images/check.jpg)



